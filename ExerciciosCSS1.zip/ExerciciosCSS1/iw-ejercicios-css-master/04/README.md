
# Ejercicio CSS: 04

Aplica los estilos necesarios a los elementos de la página ejercicio04.html para obtener como resultado una apariencia como la de la siguiente imagen:

![alt text](https://github.com/jvadillo/iw-ejercicios-css/blob/master/04/resultado.png "Resultado final")