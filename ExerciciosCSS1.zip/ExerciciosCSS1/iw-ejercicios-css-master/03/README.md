
# Ejercicio CSS: 03

Aplica los estilos necesarios a los elementos de la página ejercicio03.html para obtener como resultado una apariencia como la de la siguiente imagen:

![alt text](https://github.com/jvadillo/iw-ejercicios-css/blob/master/03/resultado.png "Resultado final")