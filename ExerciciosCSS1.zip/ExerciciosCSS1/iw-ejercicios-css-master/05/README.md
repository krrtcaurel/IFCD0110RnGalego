
# Ejercicio CSS: 05

Aplica los estilos necesarios a los elementos de la página 05-floats.html para que se muestre un resultado como el de la imagen. Algunos datos sobre los estilos a aplicar:

* El margen interior del párrafo con borde es de 8px en todos sus lados.
* La separación entre el párrafo con borde y sin borde es de 14px.
* La anchura del párrafo con borde es de 200px.

![alt text](https://github.com/jvadillo/iw-ejercicios-css/blob/master/05/resultado.png "Resultado final")
